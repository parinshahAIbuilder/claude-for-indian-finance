# Finance Operations

Indian F&A close: GSTR-2B ITC reconciliation, TDS audit, MSME 43B(h), bank reconciliation, trial balance close gate, budget vs actual, receivables ECL, journal entry testing.

Part of [Claude for Indian Finance](https://github.com/parinshahAIbuilder/claude-for-indian-finance), Claude plugins for Indian finance, accounts and listed-company compliance, written by a practising listed-company CFO (CA, CPA).

## Install

```
/plugin marketplace add parinshahAIbuilder/claude-for-indian-finance
```

```
/plugin install finance-operations@claude-for-indian-finance
```

## Skills

| Skill | What it does |
|---|---|
| bank-reconciliation-brs | Reconcile a bank book (Tally, SAP, Zoho, Busy or any ERP ledger export) against the bank statement (PDF, Excel or CSV from any Indian or international bank) and produce a classic Bank Reconciliation… |
| budget-vs-actual-commentary | Turn a budget file and an actuals file (GL, trial balance or MIS, single entity or branch-wise / cost-centre-wise / region-wise) into a Budget vs Actual pack, with month and year-to-date variances… |
| gstr2b-itc-reconciler | Reconcile an Indian purchase register (Tally, SAP, Zoho, Busy or any ERP export) against GSTR-2B / IMS downloads and return matched, mismatched, missing-in-2B and missing-in-books invoices, the ITC… |
| journal-entry-red-flag-scanner | Scan a full general ledger or day book export (Tally, SAP, Oracle, Zoho, Busy, or any ERP) for the journal-entry red flags that auditors test under SA 240 / ISA 240 and SA 330, and that Section… |
| msme-43bh-payables-gate | Test an Indian company's trade payables and vendor payments against the MSMED Act 2006 payment deadlines (15 days, or up to 45 days by written agreement) and Section 43B(h) of the Income-tax Act |
| receivables-ageing-ecl | Build trade receivables ageing in the Schedule III format and an Ind AS 109 expected credit loss (ECL) provision matrix, using the simplified approach with historical loss rates and a forward-looking… |
| tds-compliance-auditor | Audit an Indian company's expense ledgers, vendor payments and TDS working against the correct TDS section, threshold and rate, then against Form 26Q/24Q filings, challans and Form 26AS / TRACES data |
| trial-balance-close-gate | Month-end and year-end close quality gate for an Indian company's trial balance |

## Commands

`/gst-itc-recon`, `/month-end-close`

## How to use

Run a command, or just describe the task (for example, attach a file and say what you need); Claude loads the matching skill. No setup or API keys are needed, and the plugin sends no data to outside services.

## Important

These skills help qualified professionals work faster. They are not legal, tax or investment advice. SEBI, MCA, CBDT, RBI and GST rules change often; every skill flags timelines and rates to confirm against the latest notification before filing.

MIT licensed. Author: [Parin Shah](https://www.linkedin.com/in/parinshah-cfo).
