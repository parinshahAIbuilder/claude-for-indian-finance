# Debt & Treasury

CMA data and MPBF for bank loans, NCD interest registers with TDS, DSCR, covenant monitoring and credit rating preparation.

Part of [Claude for Indian Finance](https://github.com/parinshahAIbuilder/claude-for-indian-finance), Claude plugins for Indian finance, accounts and listed-company compliance, written by a practising listed-company CFO (CA, CPA).

## Install

```
/plugin marketplace add parinshahAIbuilder/claude-for-indian-finance
```

```
/plugin install debt-and-treasury@claude-for-indian-finance
```

## Skills

| Skill | What it does |
|---|---|
| cma-bank-loan | Prepare CMA (Credit Monitoring Arrangement) data for an Indian bank or NBFC loan proposal — Forms I to VI, MPBF / drawing power for working capital, term loan DSCR and repayment schedule, key ratios… |
| dscr-credit-rating | Prepare an Indian company for a credit rating (CRISIL, ICRA, CARE, India Ratings, Acuite, Infomerics, Brickwork) or a lender covenant test — DSCR, ISCR, net debt / EBITDA, TOL / TNW and liquidity… |
| ncd-interest-register | Prepare the interest and redemption payout register for listed or unlisted Indian NCDs / debentures — holder-wise interest from the RTA benpos, day count per the trust deed, holiday convention, TDS… |

## Commands

`/cma`, `/ncd-interest`, `/rating-pack`

## How to use

Run a command, or just describe the task (for example, attach a file and say what you need); Claude loads the matching skill. No setup or API keys are needed, and the plugin sends no data to outside services.

## Important

These skills help qualified professionals work faster. They are not legal, tax or investment advice. SEBI, MCA, CBDT, RBI and GST rules change often; every skill flags timelines and rates to confirm against the latest notification before filing.

MIT licensed. Author: [Parin Shah](https://www.linkedin.com/in/parinshah-cfo).
