# Financial Reporting

Trial balance to audit-ready financial statements (Ind AS, AS, IFRS, US GAAP) and Ind AS 116 lease accounting with the IGAAP bridge.

Part of [Claude for Indian Finance](https://github.com/parinshahAIbuilder/claude-for-indian-finance), Claude plugins for Indian finance, accounts and listed-company compliance, written by a practising listed-company CFO (CA, CPA).

## Install

```
/plugin marketplace add parinshahAIbuilder/claude-for-indian-finance
```

```
/plugin install financial-reporting@claude-for-indian-finance
```

## Skills

| Skill | What it does |
|---|---|
| financial-statements-builder | Turn a trial balance, general ledger export, or live ERP data (Zoho Books, Tally, QuickBooks, Xero, SAP, NetSuite or any API-enabled ERP) into a signed-off-ready financial statements bundle — Balance… |
| ind-as-116-leases | Build Ind AS 116 lessee accounting for Indian companies — lease register, right-of-use asset and lease liability schedules, monthly journal entries, deferred tax, modifications, and the Ind AS to… |

## Commands

`/build-financials`, `/ind-as-116`

## How to use

Run a command, or just describe the task (for example, attach a file and say what you need); Claude loads the matching skill. No setup or API keys are needed, and the plugin sends no data to outside services.

## Important

These skills help qualified professionals work faster. They are not legal, tax or investment advice. SEBI, MCA, CBDT, RBI and GST rules change often; every skill flags timelines and rates to confirm against the latest notification before filing.

MIT licensed. Author: [Parin Shah](https://www.linkedin.com/in/parinshah-cfo).
