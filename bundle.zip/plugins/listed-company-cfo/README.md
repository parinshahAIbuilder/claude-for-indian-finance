# Listed Company CFO

SEBI LODR disclosure desk, results-day checklist, IPO offer document review, annual report review and review markup for NSE / BSE listed companies.

Part of [Claude for Indian Finance](https://github.com/parinshahAIbuilder/claude-for-indian-finance), Claude plugins for Indian finance, accounts and listed-company compliance, written by a practising listed-company CFO (CA, CPA).

## Install

```
/plugin marketplace add parinshahAIbuilder/claude-for-indian-finance
```

```
/plugin install listed-company-cfo@claude-for-indian-finance
```

## Skills

| Skill | What it does |
|---|---|
| annual-report-review | Forensic pre signing review of a listed Indian company's annual report financial statements, standalone and consolidated, together with the independent auditor's report, CARO 2020 annexure and… |
| ipo-offer-document-review | Forensic regulatory and investor review of Indian IPO offer documents against SEBI ICDR 2018, SEBI LODR, the Companies Act 2013, Schedule III, Ind AS and tax law |
| review-markup | Marks review findings into the client's own documents rather than writing them up separately: colour coded highlights with severity graded popup comments in PDF financial statements, tracked changes… |
| sebi-lodr-disclosure | Decide whether an event at an Indian listed company must be disclosed under SEBI LODR Regulation 30, compute the materiality threshold, start the disclosure clock and draft the stock exchange intimation for NSE / BSE |

## Commands

`/reg30`, `/results-checklist`, `/review-annual-report`, `/review-drhp`

## How to use

Run a command, or just describe the task (for example, attach a file and say what you need); Claude loads the matching skill. No setup or API keys are needed, and the plugin sends no data to outside services.

## Important

These skills help qualified professionals work faster. They are not legal, tax or investment advice. SEBI, MCA, CBDT, RBI and GST rules change often; every skill flags timelines and rates to confirm against the latest notification before filing.

MIT licensed. Author: [Parin Shah](https://www.linkedin.com/in/parinshah-cfo).
